using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using GantsPlace.Services;

namespace GantsPlace.Views
{
    public partial class LoginPage : Page
    {
        private readonly MainWindow _mainWindow;

        public LoginPage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            TxtEmail.TextChanged += (s, e) => PlaceholderEmail.Visibility = string.IsNullOrEmpty(TxtEmail.Text) ? Visibility.Visible : Visibility.Collapsed;
            TxtPassword.PasswordChanged += (s, e) => PlaceholderPwd.Visibility = string.IsNullOrEmpty(TxtPassword.Password) ? Visibility.Visible : Visibility.Collapsed;
        }

        private void BtnLogin_Click(object sender, RoutedEventArgs e)
        {
            string email = TxtEmail.Text.Trim();
            string pwd = TxtPassword.Password;

            if (string.IsNullOrEmpty(email) || string.IsNullOrEmpty(pwd))
            {
                ShowError("Veuillez remplir tous les champs.");
                return;
            }

            if (DataService.Authentifier(email, pwd))
            {
                _mainWindow.RefreshAuthButtons();
                _mainWindow.NavigateTo("Accueil");
                _mainWindow.UpdateNavButtons("Accueil");
            }
            else
            {
                ShowError("Email ou mot de passe incorrect.");
            }
        }

        private void ShowError(string msg)
        {
            TxtErreur.Text = msg;
            TxtErreur.Visibility = Visibility.Visible;
        }

        private void GoToInscription(object sender, MouseButtonEventArgs e)
        {
            _mainWindow.NavigateTo("Inscription");
        }
    }
}
