using System.Windows;
using System.Windows.Controls;
using GantsPlace.Services;

namespace GantsPlace.Views
{
    public partial class InscriptionPage : Page
    {
        private readonly MainWindow _mainWindow;

        public InscriptionPage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            TxtNom.TextChanged      += (s, e) => HidePlaceholder(PhNom, TxtNom.Text);
            TxtEmail.TextChanged    += (s, e) => HidePlaceholder(PhEmail, TxtEmail.Text);
            TxtPassword.PasswordChanged += (s, e) => HidePlaceholder(PhPwd, TxtPassword.Password);
            TxtConfirm.PasswordChanged  += (s, e) => HidePlaceholder(PhConfirm, TxtConfirm.Password);
        }

        private void HidePlaceholder(TextBlock ph, string text) =>
            ph.Visibility = string.IsNullOrEmpty(text) ? Visibility.Visible : Visibility.Collapsed;

        private void BtnSignUp_Click(object sender, RoutedEventArgs e)
        {
            TxtErreur.Visibility = Visibility.Collapsed;

            if (string.IsNullOrWhiteSpace(TxtNom.Text))       { ShowErr("Le nom est obligatoire."); return; }
            if (string.IsNullOrWhiteSpace(TxtEmail.Text))     { ShowErr("L'email est obligatoire."); return; }
            if (TxtPassword.Password.Length < 6)              { ShowErr("Le mot de passe doit contenir au moins 6 caractères."); return; }
            if (TxtPassword.Password != TxtConfirm.Password)  { ShowErr("Les mots de passe ne correspondent pas."); return; }

            bool ok = DataService.Inscrire(TxtNom.Text.Trim(), TxtEmail.Text.Trim(), TxtPassword.Password);
            if (!ok) { ShowErr("Un compte existe déjà avec cet email."); return; }

            // 🔔 Notification de bienvenue
            _mainWindow.RefreshAuthButtons();
            MessageBox.Show(
                $"🎉 Bienvenue chez Gands Place, {TxtNom.Text.Trim()} !\n\n" +
                $"Votre compte a été créé avec succès.\n" +
                $"Email : {TxtEmail.Text.Trim()}\n\n" +
                $"Vous pouvez maintenant réserver vos salles.",
                "Compte créé avec succès ✅",
                MessageBoxButton.OK, MessageBoxImage.Information);

            _mainWindow.NavigateTo("Accueil");
            _mainWindow.UpdateNavButtons("Accueil");
        }

        private void ShowErr(string msg)
        {
            TxtErreur.Text = msg;
            TxtErreur.Visibility = Visibility.Visible;
        }

        private void GoToLogin(object sender, System.Windows.Input.MouseButtonEventArgs e) =>
            _mainWindow.NavigateTo("Login");
    }
}
