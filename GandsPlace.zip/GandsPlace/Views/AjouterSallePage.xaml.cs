using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using GantsPlace.Models;
using GantsPlace.Services;

namespace GantsPlace.Views
{
    public partial class AjouterSallePage : Page
    {
        private readonly MainWindow _mainWindow;

        public AjouterSallePage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            if (!Session.EstAdmin)
            {
                MessageBox.Show("Accès refusé.", "Interdit", MessageBoxButton.OK, MessageBoxImage.Warning);
                _mainWindow.NavigateTo("Accueil");
            }
        }

        private void BtnAjouter_Click(object sender, RoutedEventArgs e)
        {
            TxtErreur.Visibility = Visibility.Collapsed;
            if (string.IsNullOrWhiteSpace(TxtNom.Text))        { Show("Le nom est obligatoire."); return; }
            if (!int.TryParse(TxtCapacite.Text, out int cap) || cap <= 0) { Show("Capacité invalide."); return; }
            if (string.IsNullOrWhiteSpace(TxtDescription.Text)) { Show("La description est obligatoire."); return; }

            // Récupérer les équipements cochés
            var equip = new List<string>();
            if (ChkProjecteur.IsChecked == true) equip.Add("Projecteur");
            if (ChkEcran.IsChecked      == true) equip.Add("Écran");
            if (ChkWifi.IsChecked       == true) equip.Add("Wi-Fi");
            if (ChkMicro.IsChecked      == true) equip.Add("Micro");

            string type = (CmbTypeSalle.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Salle de réunion";

            var salle = new Salle
            {
                Nom         = TxtNom.Text.Trim(),
                TypeSalle   = type,
                Capacite    = cap,
                Equipements = equip,
                ImagePath   = string.IsNullOrWhiteSpace(TxtImage.Text) ? null : TxtImage.Text.Trim(),
                Description = TxtDescription.Text.Trim()
            };

            DataService.AjouterSalle(salle);
            MessageBox.Show($"✅ Salle \"{salle.Nom}\" ajoutée avec succès !",
                "Salle ajoutée", MessageBoxButton.OK, MessageBoxImage.Information);
            _mainWindow.NavigateTo("Explorer");
            _mainWindow.UpdateNavButtons("Explorer");
        }

        private void Show(string msg) { TxtErreur.Text = msg; TxtErreur.Visibility = Visibility.Visible; }

        private void BtnRetour_Click(object sender, RoutedEventArgs e)
        { _mainWindow.NavigateTo("Explorer"); _mainWindow.UpdateNavButtons("Explorer"); }
    }
}
