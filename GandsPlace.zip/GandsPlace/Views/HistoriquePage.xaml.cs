using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using GantsPlace.Models;
using GantsPlace.Services;

namespace GantsPlace.Views
{
    public partial class HistoriquePage : Page
    {
        private readonly MainWindow _mainWindow;

        public HistoriquePage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            LoadReservations();
        }

        private void LoadReservations()
        {
            ListeReservations.Children.Clear();

            if (!Session.EstConnecte)
            {
                TxtSoustitre.Text = "Connectez-vous pour voir vos réservations.";
                var btn = new Button { Content="Se connecter", Margin=new Thickness(0,20,0,0),
                    Padding=new Thickness(24,12,24,12),
                    Background=new SolidColorBrush(Color.FromRgb(26,26,26)),
                    Foreground=Brushes.White, BorderThickness=new Thickness(0),
                    Cursor=System.Windows.Input.Cursors.Hand,
                    FontFamily=new FontFamily("Segoe UI"), FontSize=14 };
                btn.Click += (s,e) => _mainWindow.NavigateTo("Login");
                ListeReservations.Children.Add(btn);
                return;
            }

            var user = Session.UtilisateurConnecte!;
            TxtSoustitre.Text = $"Bienvenue, {user.NomComplet} — {user.Reservations.Count} réservation(s)";

            if (user.Reservations.Count == 0)
            {
                ListeReservations.Children.Add(new TextBlock {
                    Text="Aucune réservation pour le moment.",
                    FontFamily=new FontFamily("Segoe UI"), FontSize=15,
                    Foreground=new SolidColorBrush(Color.FromRgb(170,170,170)),
                    Margin=new Thickness(0,20,0,0) });
                return;
            }

            foreach (var r in user.Reservations) ListeReservations.Children.Add(CreateCard(r));
        }

        private Border CreateCard(Reservation r)
        {
            var card = new Border {
                Background=new SolidColorBrush(Color.FromRgb(55,55,55)),
                CornerRadius=new CornerRadius(12), Padding=new Thickness(20),
                Margin=new Thickness(0,0,0,12),
                Effect=new DropShadowEffect { ShadowDepth=2, BlurRadius=8, Opacity=0.3, Color=Colors.Black }
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width=new System.Windows.GridLength(1, System.Windows.GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width=new System.Windows.GridLength(1, System.Windows.GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width=System.Windows.GridLength.Auto });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width=System.Windows.GridLength.Auto });

            // Infos salle
            var left = new StackPanel();
            left.Children.Add(new TextBlock { Text=r.SalleNom, FontFamily=new FontFamily("Segoe UI"),
                FontSize=17, FontWeight=FontWeights.Bold, Foreground=Brushes.White, Margin=new Thickness(0,0,0,4) });
            left.Children.Add(new TextBlock { Text=r.TypeSalle, FontFamily=new FontFamily("Segoe UI"),
                FontSize=13, Foreground=new SolidColorBrush(Color.FromRgb(170,170,170)) });
            Grid.SetColumn(left, 0);

            // Date/heure
            var center = new StackPanel { VerticalAlignment=VerticalAlignment.Center };
            center.Children.Add(new TextBlock { Text=$"📅 {r.DateFormatee}",
                FontFamily=new FontFamily("Segoe UI"), FontSize=14, Foreground=Brushes.White, Margin=new Thickness(0,0,0,4) });
            center.Children.Add(new TextBlock { Text=$"🕐 {r.HeuresFormatees}",
                FontFamily=new FontFamily("Segoe UI"), FontSize=13,
                Foreground=new SolidColorBrush(Color.FromRgb(200,200,200)) });
            Grid.SetColumn(center, 1);

            // Badge statut — uniquement Confirmée (vert) ou Annulée (rouge)
            if (r.Statut == "Confirmée" || r.Statut == "Annulée")
            {
                var col = r.Statut == "Confirmée" ? Color.FromRgb(72,199,116) : Color.FromRgb(220,80,80);
                var badge = new Border { Background=new SolidColorBrush(col),
                    CornerRadius=new CornerRadius(20), Padding=new Thickness(14,6,14,6),
                    VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(12,0,0,0) };
                badge.Child = new TextBlock { Text=r.Statut, FontFamily=new FontFamily("Segoe UI"),
                    FontSize=12, FontWeight=FontWeights.SemiBold, Foreground=Brushes.White };
                Grid.SetColumn(badge, 2);
                grid.Children.Add(badge);
            }

            // Bouton Annuler (seulement si active)
            if (r.Statut == "En attente" || r.Statut == "Confirmée")
            {
                var btnAnnuler = new Button { Content="Annuler",
                    Margin=new Thickness(10,0,0,0), Padding=new Thickness(14,6,14,6),
                    Background=new SolidColorBrush(Color.FromRgb(60,60,60)),
                    Foreground=new SolidColorBrush(Color.FromRgb(220,80,80)),
                    BorderThickness=new Thickness(1),
                    BorderBrush=new SolidColorBrush(Color.FromRgb(220,80,80)),
                    FontFamily=new FontFamily("Segoe UI"), FontSize=12, FontWeight=FontWeights.SemiBold,
                    Cursor=System.Windows.Input.Cursors.Hand, VerticalAlignment=VerticalAlignment.Center };
                var res = r;
                btnAnnuler.Click += (s,e) =>
                {
                    var result = MessageBox.Show($"Annuler la réservation de « {res.SalleNom} » du {res.DateFormatee} ?",
                        "Confirmer l'annulation", MessageBoxButton.YesNo, MessageBoxImage.Question);
                    if (result == MessageBoxResult.Yes) { DataService.AnnulerReservation(res); LoadReservations(); }
                };
                Grid.SetColumn(btnAnnuler, 3);
                grid.Children.Add(btnAnnuler);
            }

            grid.Children.Add(left);
            grid.Children.Add(center);
            card.Child = grid;
            return card;
        }
    }
}
