using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Effects;
using GantsPlace.Models;
using GantsPlace.Services;

namespace GantsPlace.Views
{
    public partial class AdminReservationsPage : Page
    {
        private readonly MainWindow _mainWindow;

        public AdminReservationsPage(MainWindow mainWindow)
        {
            InitializeComponent();
            _mainWindow = mainWindow;
            if (!Session.EstAdmin) { _mainWindow.NavigateTo("Accueil"); return; }
            LoadReservations();
        }

        private void LoadReservations()
        {
            var all  = DataService.ToutesReservations.AsEnumerable();
            string f = (CmbFiltreStatut?.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Toutes";
            if (f != "Toutes") all = all.Where(r => r.Statut == f);

            var list = all.ToList();
            TxtCompte.Text = $"— {list.Count} réservation(s)";
            ListePanel.Children.Clear();

            if (list.Count == 0)
            {
                ListePanel.Children.Add(new TextBlock {
                    Text="Aucune réservation.", FontFamily=new FontFamily("Segoe UI"),
                    FontSize=15, Foreground=new SolidColorBrush(Color.FromRgb(170,170,170)),
                    Margin=new Thickness(0,20,0,0) });
                return;
            }

            foreach (var r in list) ListePanel.Children.Add(CreateCard(r));
        }

        private Border CreateCard(Reservation r)
        {
            var card = new Border {
                Background=new SolidColorBrush(Color.FromRgb(50,50,50)),
                CornerRadius=new CornerRadius(12), Padding=new Thickness(20),
                Margin=new Thickness(0,0,0,12),
                Effect=new DropShadowEffect { ShadowDepth=2, BlurRadius=8, Opacity=0.25, Color=Colors.Black }
            };

            var grid = new Grid();
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width=new System.Windows.GridLength(1, System.Windows.GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width=new System.Windows.GridLength(1, System.Windows.GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width=new System.Windows.GridLength(1, System.Windows.GridUnitType.Star) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width=System.Windows.GridLength.Auto });

            // Col 1 : salle
            var col1 = new StackPanel();
            col1.Children.Add(new TextBlock { Text=r.SalleNom, FontFamily=new FontFamily("Segoe UI"),
                FontSize=16, FontWeight=FontWeights.Bold, Foreground=Brushes.White, Margin=new Thickness(0,0,0,3) });
            col1.Children.Add(new TextBlock { Text=r.TypeSalle, FontFamily=new FontFamily("Segoe UI"),
                FontSize=12, Foreground=new SolidColorBrush(Color.FromRgb(160,160,160)) });
            Grid.SetColumn(col1, 0);

            // Col 2 : user + date
            var col2 = new StackPanel { VerticalAlignment=VerticalAlignment.Center };
            col2.Children.Add(new TextBlock { Text=$"👤 {r.UserNom}", FontFamily=new FontFamily("Segoe UI"),
                FontSize=13, Foreground=Brushes.White, Margin=new Thickness(0,0,0,3) });
            col2.Children.Add(new TextBlock { Text=r.UserEmail, FontFamily=new FontFamily("Segoe UI"),
                FontSize=12, Foreground=new SolidColorBrush(Color.FromRgb(160,160,160)) });
            Grid.SetColumn(col2, 1);

            // Col 3 : créneau
            var col3 = new StackPanel { VerticalAlignment=VerticalAlignment.Center };
            col3.Children.Add(new TextBlock { Text=$"📅 {r.DateFormatee}", FontFamily=new FontFamily("Segoe UI"),
                FontSize=14, Foreground=Brushes.White, Margin=new Thickness(0,0,0,3) });
            col3.Children.Add(new TextBlock { Text=$"🕐 {r.HeuresFormatees}", FontFamily=new FontFamily("Segoe UI"),
                FontSize=13, Foreground=new SolidColorBrush(Color.FromRgb(200,200,200)) });
            Grid.SetColumn(col3, 2);

            // Col 4 : actions
            var actions = new StackPanel { Orientation=Orientation.Horizontal,
                VerticalAlignment=VerticalAlignment.Center, Margin=new Thickness(16,0,0,0) };

            if (r.Statut == "En attente")
            {
                // Bouton Confirmer
                var btnConfirmer = new Button { Content="✅ Confirmer",
                    Padding=new Thickness(14,8,14,8), Margin=new Thickness(0,0,8,0),
                    Background=new SolidColorBrush(Color.FromRgb(72,199,116)),
                    Foreground=Brushes.White, BorderThickness=new Thickness(0),
                    FontFamily=new FontFamily("Segoe UI"), FontSize=13, FontWeight=FontWeights.SemiBold,
                    Cursor=System.Windows.Input.Cursors.Hand };
                btnConfirmer.Template = RoundedButtonTemplate(new SolidColorBrush(Color.FromRgb(72,199,116)),
                                                               new SolidColorBrush(Color.FromRgb(50,170,90)));
                var res = r;
                btnConfirmer.Click += (s,e) =>
                {
                    DataService.ConfirmerReservation(res);
                    LoadReservations();
                };
                actions.Children.Add(btnConfirmer);

                // Bouton Refuser
                var btnRefuser = new Button { Content="❌ Refuser",
                    Padding=new Thickness(14,8,14,8),
                    Background=new SolidColorBrush(Color.FromRgb(220,80,80)),
                    Foreground=Brushes.White, BorderThickness=new Thickness(0),
                    FontFamily=new FontFamily("Segoe UI"), FontSize=13, FontWeight=FontWeights.SemiBold,
                    Cursor=System.Windows.Input.Cursors.Hand };
                btnRefuser.Template = RoundedButtonTemplate(new SolidColorBrush(Color.FromRgb(220,80,80)),
                                                             new SolidColorBrush(Color.FromRgb(180,50,50)));
                btnRefuser.Click += (s,e) =>
                {
                    DataService.AnnulerReservation(res);
                    LoadReservations();
                };
                actions.Children.Add(btnRefuser);
            }
            else
            {
                // Badge statut final
                var col = r.Statut == "Confirmée" ? Color.FromRgb(72,199,116) : Color.FromRgb(220,80,80);
                var badge = new Border { Background=new SolidColorBrush(col),
                    CornerRadius=new CornerRadius(20), Padding=new Thickness(14,6,14,6) };
                badge.Child = new TextBlock { Text=r.Statut, FontFamily=new FontFamily("Segoe UI"),
                    FontSize=12, FontWeight=FontWeights.SemiBold, Foreground=Brushes.White };
                actions.Children.Add(badge);
            }

            Grid.SetColumn(actions, 3);
            grid.Children.Add(col1);
            grid.Children.Add(col2);
            grid.Children.Add(col3);
            grid.Children.Add(actions);
            card.Child = grid;
            return card;
        }

        // Template bouton arrondi avec hover
        private System.Windows.Controls.ControlTemplate RoundedButtonTemplate(SolidColorBrush normal, SolidColorBrush hover)
        {
            var tpl = new System.Windows.Controls.ControlTemplate(typeof(Button));
            var bd  = new System.Windows.FrameworkElementFactory(typeof(Border));
            bd.SetValue(Border.BackgroundProperty, normal);
            bd.SetValue(Border.CornerRadiusProperty, new CornerRadius(20));
            bd.SetValue(Border.PaddingProperty, new Thickness(0));
            var cp = new System.Windows.FrameworkElementFactory(typeof(ContentPresenter));
            cp.SetValue(ContentPresenter.HorizontalAlignmentProperty, HorizontalAlignment.Center);
            cp.SetValue(ContentPresenter.VerticalAlignmentProperty, VerticalAlignment.Center);
            cp.SetValue(ContentPresenter.MarginProperty, new Thickness(14, 8, 14, 8));
            bd.AppendChild(cp);
            tpl.VisualTree = bd;
            return tpl;
        }

        private void FiltreChanged(object sender, SelectionChangedEventArgs e)
        { if (ListePanel != null) LoadReservations(); }
    }
}
