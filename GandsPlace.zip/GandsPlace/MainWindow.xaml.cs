using System.Windows;
using System.Windows.Controls;
using GantsPlace.Models;
using GantsPlace.Views;

namespace GantsPlace
{
    public partial class MainWindow : Window
    {
        private bool _mainAppVisible = false;

        public MainWindow()
        {
            InitializeComponent();
            MainFrame.Navigate(new DemarragePage(this));
            NavBar.Visibility = Visibility.Collapsed;
        }

        public void ShowMainApp()
        {
            if (!_mainAppVisible)
            {
                _mainAppVisible = true;
                NavBar.Visibility = Visibility.Visible;
                RefreshAuthButtons();
            }
            NavigateTo("Accueil");
            UpdateNavButtons("Accueil");
        }

        public void NavigateTo(string page, object? parameter = null)
        {
            switch (page)
            {
                case "Accueil":           MainFrame.Navigate(new AccueilPage(this)); break;
                case "Explorer":          MainFrame.Navigate(new ExplorerPage(this)); break;
                case "Historique":        MainFrame.Navigate(new HistoriquePage(this)); break;
                case "Contact":           MainFrame.Navigate(new ContactPage(this)); break;
                case "Login":             MainFrame.Navigate(new LoginPage(this)); break;
                case "Inscription":       MainFrame.Navigate(new InscriptionPage(this)); break;
                case "AjouterSalle":      MainFrame.Navigate(new AjouterSallePage(this)); break;
                case "AdminReservations": MainFrame.Navigate(new AdminReservationsPage(this)); break;
                case "DetailSalle":
                    if (parameter is Salle s) MainFrame.Navigate(new DetailSallePage(this, s));
                    break;
            }
        }

        public void UpdateNavButtons(string activePage)
        {
            BtnAccueil.Style    = activePage == "Accueil"    ? (Style)FindResource("NavButtonActiveStyle") : (Style)FindResource("NavButtonStyle");
            BtnExplorer.Style   = activePage == "Explorer"   ? (Style)FindResource("NavButtonActiveStyle") : (Style)FindResource("NavButtonStyle");
            BtnHistorique.Style = activePage == "Historique" ? (Style)FindResource("NavButtonActiveStyle") : (Style)FindResource("NavButtonStyle");
            BtnContact.Style    = activePage == "Contact"    ? (Style)FindResource("NavButtonActiveStyle") : (Style)FindResource("NavButtonStyle");
        }

        public void RefreshAuthButtons()
        {
            if (Session.EstConnecte)
            {
                BtnConnexion.Visibility   = Visibility.Collapsed;
                BtnInscription.Visibility = Visibility.Collapsed;
                BtnDeconnexion.Visibility = Visibility.Visible;
                TxtUserName.Text          = Session.UtilisateurConnecte!.NomComplet;
                TxtUserName.Visibility    = Visibility.Visible;
                // Boutons admin
                BtnAdmin.Visibility           = Session.EstAdmin ? Visibility.Visible : Visibility.Collapsed;
                BtnAdminReservations.Visibility = Session.EstAdmin ? Visibility.Visible : Visibility.Collapsed;
            }
            else
            {
                BtnConnexion.Visibility   = Visibility.Visible;
                BtnInscription.Visibility = Visibility.Visible;
                BtnDeconnexion.Visibility = Visibility.Collapsed;
                TxtUserName.Visibility    = Visibility.Collapsed;
                BtnAdmin.Visibility           = Visibility.Collapsed;
                BtnAdminReservations.Visibility = Visibility.Collapsed;
            }
        }

        private void BtnAccueil_Click(object sender, RoutedEventArgs e)    { NavigateTo("Accueil");    UpdateNavButtons("Accueil"); }
        private void BtnExplorer_Click(object sender, RoutedEventArgs e)   { NavigateTo("Explorer");   UpdateNavButtons("Explorer"); }
        private void BtnContact_Click(object sender, RoutedEventArgs e)    { NavigateTo("Contact");    UpdateNavButtons("Contact"); }
        private void BtnHistorique_Click(object sender, RoutedEventArgs e) { NavigateTo("Historique"); UpdateNavButtons("Historique"); }
        private void BtnConnexion_Click(object sender, RoutedEventArgs e)  { NavigateTo("Login"); }
        private void BtnInscription_Click(object sender, RoutedEventArgs e){ NavigateTo("Inscription"); }
        private void BtnAdmin_Click(object sender, RoutedEventArgs e)      { NavigateTo("AjouterSalle"); }
        private void BtnAdminReservations_Click(object sender, RoutedEventArgs e) { NavigateTo("AdminReservations"); }

        private void BtnDeconnexion_Click(object sender, RoutedEventArgs e)
        {
            Session.UtilisateurConnecte = null;
            RefreshAuthButtons();
            NavigateTo("Accueil");
            UpdateNavButtons("Accueil");
        }
    }
}
