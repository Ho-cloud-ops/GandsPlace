using System.Windows;

namespace GantsPlace
{
    public partial class App : Application
    {
    }
}
