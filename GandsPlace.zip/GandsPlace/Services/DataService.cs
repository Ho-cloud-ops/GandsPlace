using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using GantsPlace.Models;

namespace GantsPlace.Services
{
    public static class DataService
    {
        public static ObservableCollection<Reservation> ToutesReservations { get; } = new();
        private static int _nextId = 10;

        private static List<Utilisateur> _utilisateurs = new()
        {
            new Utilisateur { Id=0, NomComplet="Administrateur", Email="admin@gandsplace.com",
                              MotDePasse="admin2024", IsAdmin=true, Reservations=new() },
            new Utilisateur { Id=1, NomComplet="Jean Dupont", Email="jean@example.com",
                              MotDePasse="password123", IsAdmin=false,
                Reservations=new ObservableCollection<Reservation>
                {
                    new Reservation { Id=1, SalleId=1, SalleNom="Salle Prestige", UserNom="Jean Dupont",
                        UserEmail="jean@example.com", Date=new System.DateTime(2026,3,10),
                        HeureDebut=new System.TimeSpan(9,0,0), HeureFin=new System.TimeSpan(13,0,0),
                        TypeSalle="Salle de réunion", Statut="En attente" },
                    new Reservation { Id=2, SalleId=8, SalleNom="Salle Innovation", UserNom="Jean Dupont",
                        UserEmail="jean@example.com", Date=new System.DateTime(2026,3,18),
                        HeureDebut=new System.TimeSpan(14,0,0), HeureFin=new System.TimeSpan(18,0,0),
                        TypeSalle="Salle de cours", Statut="En attente" },
                }
            }
        };

        public static List<Salle> Salles { get; } = new()
        {
            // ── Salles de réunion ────────────────────────────────────────────────
            new Salle { Id=1,  ImagePath="salle1.jpg",  Nom="Salle Prestige",
                TypeSalle="Salle de réunion", Capacite=20, Localisation="Lomé Plateau",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Salle de réunion haut de gamme pour vos rendez-vous professionnels importants." },

            new Salle { Id=2,  ImagePath="salle2.jpg",  Nom="Salle Executive",
                TypeSalle="Salle de réunion", Capacite=10, Localisation="Lomé Tokoin",
                Equipements=new(){"Écran","Wi-Fi"},
                Description="Espace intime et confidentiel pour vos comités de direction." },

            new Salle { Id=3,  ImagePath="salle3.jpg",  Nom="Salle Lumière",
                TypeSalle="Salle de réunion", Capacite=30, Localisation="Lomé Bè",
                Equipements=new(){"Projecteur","Wi-Fi","Micro"},
                Description="Grande salle de réunion lumineuse avec vue sur le jardin intérieur." },

            new Salle { Id=4,  ImagePath="salle4.jpg",  Nom="Salle Horizon",
                TypeSalle="Salle de réunion", Capacite=15, Localisation="Lomé Agoè",
                Equipements=new(){"Projecteur","Écran","Wi-Fi"},
                Description="Salle moderne pour réunions de direction et séances de travail." },

            new Salle { Id=5,  ImagePath="salle5.jpg",  Nom="Salle Créative",
                TypeSalle="Salle de réunion", Capacite=12, Localisation="Lomé Adidogomé",
                Equipements=new(){"Écran","Wi-Fi"},
                Description="Espace convivial pensé pour les brainstormings et réunions créatives." },

            new Salle { Id=6,  ImagePath="salle6.jpg",  Nom="Salle Panorama",
                TypeSalle="Salle de réunion", Capacite=25, Localisation="Lomé Baguida",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Salle avec vue sur le lac Togo, idéale pour vos réunions d'équipe." },

            new Salle { Id=7,  ImagePath="salle7.jpg",  Nom="Salle Diamant",
                TypeSalle="Salle de réunion", Capacite=18, Localisation="Lomé Tokoin",
                Equipements=new(){"Projecteur","Wi-Fi"},
                Description="Salle élégante pour vos rendez-vous professionnels quotidiens." },

            // ── Salles de cours ─────────────────────────────────────────────────
            new Salle { Id=8,  ImagePath="salle8.jpg",  Nom="Salle Innovation",
                TypeSalle="Salle de cours", Capacite=40, Localisation="Lomé Plateau",
                Equipements=new(){"Projecteur","Écran","Wi-Fi"},
                Description="Salle de cours modulable avec matériel pédagogique complet." },

            new Salle { Id=9,  ImagePath="salle9.jpg",  Nom="Salle Formation Pro",
                TypeSalle="Salle de cours", Capacite=30, Localisation="Lomé Nyékonakpoè",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Salle dédiée à la formation professionnelle, projecteur HD intégré." },

            new Salle { Id=10, ImagePath="salle10.jpg", Nom="Salle Découverte",
                TypeSalle="Salle de cours", Capacite=35, Localisation="Lomé Cacaveli",
                Equipements=new(){"Projecteur","Wi-Fi"},
                Description="Espace pédagogique adapté aux formations pratiques et ateliers." },

            new Salle { Id=11, ImagePath="salle11.jpg", Nom="Salle Numérique",
                TypeSalle="Salle de cours", Capacite=25, Localisation="Lomé Djidjolé",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Salle high-tech pour formations numériques et cours informatiques." },

            new Salle { Id=12, ImagePath="salle12.jpg", Nom="Salle Savoir",
                TypeSalle="Salle de cours", Capacite=50, Localisation="Lomé Légbassito",
                Equipements=new(){"Projecteur","Écran","Wi-Fi"},
                Description="Grande salle de cours pour les formations à grande envergure." },

            new Salle { Id=13, ImagePath="salle13.jpg", Nom="Salle Étoile",
                TypeSalle="Salle de cours", Capacite=28, Localisation="Lomé Kodjoviakopé",
                Equipements=new(){"Projecteur","Wi-Fi","Micro"},
                Description="Salle conviviale avec tableau interactif et connexion fibre optique." },

            new Salle { Id=14, ImagePath="salle14.jpg", Nom="Salle Avenir",
                TypeSalle="Salle de cours", Capacite=45, Localisation="Lomé Agbalépédogan",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Grande salle de formation avec estrade et système audio professionnel." },

            // ── Amphithéâtres ────────────────────────────────────────────────────
            new Salle { Id=15, ImagePath="salle15.jpg", Nom="Grand Auditorium",
                TypeSalle="Amphithéâtre", Capacite=200, Localisation="Lomé Kodjoviakopé",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Vaste amphithéâtre pour vos grands séminaires et conférences." },

            new Salle { Id=16, ImagePath="salle16.jpg", Nom="Amphithéâtre Cacaveli",
                TypeSalle="Amphithéâtre", Capacite=300, Localisation="Lomé Cacaveli",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Le plus grand espace de Gands Place pour congrès et assemblées générales." },

            new Salle { Id=17, ImagePath="salle17.jpg", Nom="Amphithéâtre Sud",
                TypeSalle="Amphithéâtre", Capacite=150, Localisation="Lomé Baguida",
                Equipements=new(){"Projecteur","Écran","Wi-Fi"},
                Description="Amphithéâtre à gradins pour conférences et remises de diplômes." },

            new Salle { Id=18, ImagePath="salle18.jpg", Nom="Salle Congrès",
                TypeSalle="Amphithéâtre", Capacite=250, Localisation="Lomé Agoè",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Salle de congrès équipée d'un système de sonorisation professionnel." },

            new Salle { Id=19, ImagePath="salle19.jpg", Nom="Amphithéâtre Tokoin",
                TypeSalle="Amphithéâtre", Capacite=120, Localisation="Lomé Tokoin",
                Equipements=new(){"Projecteur","Wi-Fi","Micro"},
                Description="Amphithéâtre moderne avec acoustique optimisée pour vos événements." },

            new Salle { Id=20, ImagePath="salle20.jpg", Nom="Amphithéâtre Lumière",
                TypeSalle="Amphithéâtre", Capacite=180, Localisation="Lomé Plateau",
                Equipements=new(){"Projecteur","Écran","Wi-Fi","Micro"},
                Description="Amphithéâtre lumineux avec terrasse pour séminaires et lancements." },
        };

        static DataService()
        {
            foreach (var u in _utilisateurs)
                foreach (var r in u.Reservations)
                    ToutesReservations.Add(r);
        }

        public static bool Authentifier(string email, string mdp)
        {
            var u = _utilisateurs.Find(u => u.Email == email && u.MotDePasse == mdp);
            if (u != null) { Session.UtilisateurConnecte = u; return true; }
            return false;
        }

        public static bool Inscrire(string nom, string email, string mdp)
        {
            if (_utilisateurs.Exists(u => u.Email == email)) return false;
            var u = new Utilisateur { Id=_utilisateurs.Count+1, NomComplet=nom,
                Email=email, MotDePasse=mdp, IsAdmin=false, Reservations=new() };
            _utilisateurs.Add(u);
            Session.UtilisateurConnecte = u;
            return true;
        }

        public static void AjouterReservation(Reservation r)
        {
            r.Id = _nextId++;
            Session.UtilisateurConnecte?.Reservations.Add(r);
            ToutesReservations.Add(r);
        }

        public static void AnnulerReservation(Reservation r)   => r.Statut = "Annulée";
        public static void ConfirmerReservation(Reservation r) => r.Statut = "Confirmée";

        public static void AjouterSalle(Salle s) { s.Id = Salles.Count + 1; Salles.Add(s); }
    }
}
